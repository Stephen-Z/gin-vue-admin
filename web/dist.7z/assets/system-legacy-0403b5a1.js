/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(t,e){"use strict";var n;return{setters:[function(t){n=t.s}],execute:function(){t("a",(function(){return n({url:"/system/getSystemConfig",method:"post"})})),t("s",(function(t){return n({url:"/system/setSystemConfig",method:"post",data:t})})),t("g",(function(){return n({url:"/system/getServerInfo",method:"post",donNotShowLoading:!0})}))}}}));
