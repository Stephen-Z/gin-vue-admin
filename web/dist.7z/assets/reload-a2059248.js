/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{u as s,o as a,c as e}from"./index-bcb8e3b8.js";const o={name:"Reload"},t=Object.assign(o,{setup:o=>(s().go(-1),(s,o)=>(a(),e("div")))});export{t as default};
