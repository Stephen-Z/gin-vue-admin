/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{o as a,c as o,b as r,F as n,d as e}from"./index-bcb8e3b8.js";import{E as t}from"./divider-dc1a1f03.js";import{_ as i}from"./_plugin-vue_export-helper-1b428a4d.js";const p={name:"BottomInfo"},s={class:"bottom-info"},l=r("span",null,"Powered by",-1),u={href:"https://github.com/flipped-aurora/gin-vue-admin"},d=r("span",null,"Copyright",-1),m=r("span",null,[r("a",{href:"https://github.com/flipped-aurora"},"flipped-aurora团队")],-1);const f=i(p,[["render",function(i,p,f,c,h,v){const b=t;return a(),o("div",s,[r("div",null,[l,r("span",null,[r("a",u,n(i.$GIN_VUE_ADMIN.appName),1)]),e(b,{direction:"vertical"}),d,m])])}]]);export{f as default};
