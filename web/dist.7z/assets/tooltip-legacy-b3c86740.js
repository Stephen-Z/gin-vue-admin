/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register([],(function(e,t){"use strict";return{execute:function(){var e=document.createElement("style");e.textContent="",document.head.appendChild(e)}}}));
