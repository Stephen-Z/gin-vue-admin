/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{b as o}from"./_baseClone-092ae1f0.js";function r(r){return o(r,5)}export{r as c};
