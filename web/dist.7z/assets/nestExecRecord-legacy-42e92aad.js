/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,t){"use strict";var r;return{setters:[function(e){r=e.s}],execute:function(){e("c",(function(e){return r({url:"/NtERecord/createNestExecRecord",method:"post",data:e})})),e("a",(function(e){return r({url:"/NtERecord/deleteNestExecRecord",method:"delete",data:e})})),e("d",(function(e){return r({url:"/NtERecord/deleteNestExecRecordByIds",method:"delete",data:e})})),e("u",(function(e){return r({url:"/NtERecord/updateNestExecRecord",method:"put",data:e})})),e("f",(function(e){return r({url:"/NtERecord/findNestExecRecord",method:"get",params:e})})),e("g",(function(e){return r({url:"/NtERecord/getNestExecRecordList",method:"get",params:e})}))}}}));
