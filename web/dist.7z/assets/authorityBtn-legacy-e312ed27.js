/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(t,n){"use strict";var r;return{setters:[function(t){r=t.s}],execute:function(){t("g",(function(t){return r({url:"/authorityBtn/getAuthorityBtn",method:"post",data:t})})),t("s",(function(t){return r({url:"/authorityBtn/setAuthorityBtn",method:"post",data:t})})),t("c",(function(t){return r({url:"/authorityBtn/canRemoveAuthorityBtn",method:"post",params:t})}))}}}));
