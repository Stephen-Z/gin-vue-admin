/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as e}from"./index-bcb8e3b8.js";const t=t=>e({url:"/NtAirline/createNestAirline",method:"post",data:t}),i=t=>e({url:"/NtAirline/deleteNestAirline",method:"delete",data:t}),r=t=>e({url:"/NtAirline/deleteNestAirlineByIds",method:"delete",data:t}),a=t=>e({url:"/NtAirline/updateNestAirline",method:"put",data:t}),l=t=>e({url:"/NtAirline/findNestAirline",method:"get",params:t}),s=t=>e({url:"/NtAirline/getNestAirlineList",method:"get",params:t});export{i as a,t as c,r as d,l as f,s as g,a as u};
