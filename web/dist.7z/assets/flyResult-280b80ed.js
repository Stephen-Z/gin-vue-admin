/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as t}from"./index-bcb8e3b8.js";const e=e=>t({url:"/FlyRt/createFlyResult",method:"post",data:e}),l=e=>t({url:"/FlyRt/deleteFlyResult",method:"delete",data:e}),a=e=>t({url:"/FlyRt/deleteFlyResultByIds",method:"delete",data:e}),s=e=>t({url:"/FlyRt/updateFlyResult",method:"put",data:e}),d=e=>t({url:"/FlyRt/findFlyResult",method:"get",params:e}),u=e=>t({url:"/FlyRt/getFlyResultList",method:"get",params:e});export{l as a,e as c,a as d,d as f,u as g,s as u};
