/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register([],(function(e,t){"use strict";return{execute:function(){var e=document.createElement("style");e.textContent=".el-icon-loading{animation:rotating 2s linear infinite}.el-icon--right{margin-left:5px}.el-icon--left{margin-right:5px}@keyframes rotating{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.el-icon{--color: inherit;height:1em;width:1em;line-height:1em;display:inline-flex;justify-content:center;align-items:center;position:relative;fill:currentColor;color:var(--color);font-size:inherit}.el-icon.is-loading{animation:rotating 2s linear infinite}.el-icon svg{height:1em;width:1em}\n",document.head.appendChild(e)}}}));
