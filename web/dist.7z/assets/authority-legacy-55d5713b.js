/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(t,u){"use strict";var r;return{setters:[function(t){r=t.s}],execute:function(){t("g",(function(t){return r({url:"/authority/getAuthorityList",method:"post",data:t})})),t("d",(function(t){return r({url:"/authority/deleteAuthority",method:"post",data:t})})),t("a",(function(t){return r({url:"/authority/createAuthority",method:"post",data:t})})),t("c",(function(t){return r({url:"/authority/copyAuthority",method:"post",data:t})})),t("s",(function(t){return r({url:"/authority/setDataAuthority",method:"post",data:t})})),t("u",(function(t){return r({url:"/authority/updateAuthority",method:"put",data:t})}))}}}));
