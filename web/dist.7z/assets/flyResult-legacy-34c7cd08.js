/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(t,e){"use strict";var u;return{setters:[function(t){u=t.s}],execute:function(){t("c",(function(t){return u({url:"/FlyRt/createFlyResult",method:"post",data:t})})),t("a",(function(t){return u({url:"/FlyRt/deleteFlyResult",method:"delete",data:t})})),t("d",(function(t){return u({url:"/FlyRt/deleteFlyResultByIds",method:"delete",data:t})})),t("u",(function(t){return u({url:"/FlyRt/updateFlyResult",method:"put",data:t})})),t("f",(function(t){return u({url:"/FlyRt/findFlyResult",method:"get",params:t})})),t("g",(function(t){return u({url:"/FlyRt/getFlyResultList",method:"get",params:t})}))}}}));
