/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./_Uint8Array-legacy-8ab4d80b.js","./index-legacy-56ea4251.js"],(function(n,t){"use strict";var e,r,u,i;return{setters:[function(n){e=n.m,r=n.a},function(n){u=n.by,i=n.aP}],execute:function(){n({b:c,f:function(n){return null!=n&&n.length?c(n,1):[]}});var t=u?u.isConcatSpreadable:void 0;function a(n){return i(n)||e(n)||!!(t&&n&&n[t])}function c(n,t,e,u,i){var o=-1,f=n.length;for(e||(e=a),i||(i=[]);++o<f;){var s=n[o];t>0&&e(s)?t>1?c(s,t-1,e,u,i):r(i,s):u||(i[i.length]=s)}return i}}}}));
