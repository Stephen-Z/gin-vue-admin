/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{f as r}from"./date-225eaf4f.js";import"./dictionary-159c2a86.js";const t=r=>null!==r?r?"是":"否":"",a=t=>{if(null!==t&&""!==t){var a=new Date(t);return r(a,"yyyy-MM-dd hh:mm:ss")}return""};export{t as a,a as f};
