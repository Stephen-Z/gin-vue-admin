/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(t,e){"use strict";var r;return{setters:[function(t){r=t.a1}],execute:function(){t({C:function(t){return e({url:"https://api.github.com/repos/flipped-aurora/gin-vue-admin/commits?page="+t,method:"get"})},M:function(){return e({url:"https://api.github.com/orgs/FLIPPED-AURORA/members",method:"get"})}});var e=r.create()}}}));
