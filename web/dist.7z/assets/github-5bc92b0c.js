/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{a1 as t}from"./index-bcb8e3b8.js";const e=t.create();function r(t){return e({url:"https://api.github.com/repos/flipped-aurora/gin-vue-admin/commits?page="+t,method:"get"})}function o(){return e({url:"https://api.github.com/orgs/FLIPPED-AURORA/members",method:"get"})}export{r as C,o as M};
