/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{bD as e}from"./index-bcb8e3b8.js";const a=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),r=a=>e(a);export{r as c,a as e};
