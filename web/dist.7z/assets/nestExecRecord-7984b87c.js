/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as e}from"./index-bcb8e3b8.js";const t=t=>e({url:"/NtERecord/createNestExecRecord",method:"post",data:t}),d=t=>e({url:"/NtERecord/deleteNestExecRecord",method:"delete",data:t}),r=t=>e({url:"/NtERecord/deleteNestExecRecordByIds",method:"delete",data:t}),o=t=>e({url:"/NtERecord/updateNestExecRecord",method:"put",data:t}),a=t=>e({url:"/NtERecord/findNestExecRecord",method:"get",params:t}),c=t=>e({url:"/NtERecord/getNestExecRecordList",method:"get",params:t});export{d as a,t as c,r as d,a as f,c as g,o as u};
