/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{f as a}from"./sysDictionary-0cfacdeb.js";import{cr as t,r as i}from"./index-bcb8e3b8.js";const r=t("dictionary",(()=>{const t=i({}),r=a=>{t.value={...t.value,...a}};return{dictionaryMap:t,setDictionaryMap:r,getDictionary:async i=>{if(t.value[i]&&t.value[i].length)return t.value[i];{const s=await a({type:i});if(0===s.code){const a={},e=[];return s.data.resysDictionary.sysDictionaryDetails&&s.data.resysDictionary.sysDictionaryDetails.forEach((a=>{e.push({label:a.label,value:a.value})})),a[s.data.resysDictionary.type]=e,r(a),t.value[i]}}}}}));export{r as u};
