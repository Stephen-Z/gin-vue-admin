/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
const o=()=>Math.floor(1e4*Math.random());export{o as g};
