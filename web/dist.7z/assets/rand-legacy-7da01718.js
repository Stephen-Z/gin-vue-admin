/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register([],(function(t,e){"use strict";return{execute:function(){t("g",(function(){return Math.floor(1e4*Math.random())}))}}}));
