/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./date-legacy-0c8a469a.js","./dictionary-legacy-2814fa19.js"],(function(n,t){"use strict";var e;return{setters:[function(n){e=n.f},null],execute:function(){n("a",(function(n){return null!==n?n?"是":"否":""})),n("f",(function(n){if(null!==n&&""!==n){var t=new Date(n);return e(t,"yyyy-MM-dd hh:mm:ss")}return""}))}}}));
