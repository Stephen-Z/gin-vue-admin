/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{o as a,c as s,d as e,w as n,C as r,cs as t,b as o,F as i,n as p,U as l}from"./index-bcb8e3b8.js";/* empty css             */import{_ as c}from"./_plugin-vue_export-helper-1b428a4d.js";const u=c({__name:"warningBar",props:{title:{type:String,default:""},href:{type:String,default:""}},setup(c){const u=c,d=()=>{u.href&&window.open(u.href)};return(u,f)=>{const _=l;return a(),s("div",{class:p(["warning-bar",c.href&&"can-click"]),onClick:d},[e(_,null,{default:n((()=>[e(r(t))])),_:1}),o("span",null,i(c.title),1)],2)}}},[["__scopeId","data-v-543a503c"]]);export{u as W};
