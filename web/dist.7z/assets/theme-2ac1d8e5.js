/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as e}from"./index-bcb8e3b8.js";const t=t=>e({url:"/theme/createTheme",method:"post",data:t}),a=t=>e({url:"/theme/deleteTheme",method:"delete",data:t}),m=t=>e({url:"/theme/deleteThemeByIds",method:"delete",data:t}),d=t=>e({url:"/theme/updateTheme",method:"put",data:t}),h=t=>e({url:"/theme/findTheme",method:"get",params:t}),s=t=>e({url:"/theme/getThemeList",method:"get",params:t});export{a,t as c,m as d,h as f,s as g,d as u};
