/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
const e=e=>e[0]?e.replace(e[0],e[0].toUpperCase()):"",a=e=>e[0]?e.replace(e[0],e[0].toLowerCase()):"",r=e=>"ID"===e?"ID":e.replace(/([A-Z])/g,"_$1").toLowerCase(),o=e=>e.replace(/\_(\w)/g,(function(e,a){return a.toUpperCase()}));export{a,e as b,o as c,r as t};
