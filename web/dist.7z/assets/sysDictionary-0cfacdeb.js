/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as t}from"./index-bcb8e3b8.js";const a=a=>t({url:"/sysDictionary/createSysDictionary",method:"post",data:a}),s=a=>t({url:"/sysDictionary/deleteSysDictionary",method:"delete",data:a}),i=a=>t({url:"/sysDictionary/updateSysDictionary",method:"put",data:a}),r=a=>t({url:"/sysDictionary/findSysDictionary",method:"get",params:a}),o=a=>t({url:"/sysDictionary/getSysDictionaryList",method:"get",params:a});export{a as c,s as d,r as f,o as g,i as u};
