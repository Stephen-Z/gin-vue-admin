/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{a8 as e,X as a,o as s,c as n,d as t,w as o,a7 as u,h as l,a9 as r,C as d,T as i}from"./index-bcb8e3b8.js";const c={name:"RouterHolder"},m=Object.assign(c,{setup(c){const m=e();return(e,c)=>{const f=a("router-view");return s(),n("div",null,[t(f,null,{default:o((({Component:e})=>[t(u,{mode:"out-in",name:"el-fade-in-linear"},{default:o((()=>[(s(),l(r,{include:d(m).keepAliveRouters},[(s(),l(i(e)))],1032,["include"]))])),_:2},1024)])),_:1})])}}});export{m as default};
