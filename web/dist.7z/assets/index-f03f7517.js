/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{a8 as e,X as a,o as s,c as n,d as t,w as u,a7 as o,h as i,a9 as l,C as r,T as d}from"./index-bcb8e3b8.js";const c={name:"SuperAdmin"},m=Object.assign(c,{setup(c){const m=e();return(e,c)=>{const p=a("router-view");return s(),n("div",null,[t(p,null,{default:u((({Component:e})=>[t(o,{mode:"out-in",name:"el-fade-in-linear"},{default:u((()=>[(s(),i(l,{include:r(m).keepAliveRouters},[(s(),i(d(e)))],1032,["include"]))])),_:2},1024)])),_:1})])}}});export{m as default};
