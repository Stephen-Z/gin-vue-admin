/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as a}from"./index-bcb8e3b8.js";const t=t=>a({url:"/api/getApiList",method:"post",data:t}),e=t=>a({url:"/api/createApi",method:"post",data:t}),p=t=>a({url:"/api/getApiById",method:"post",data:t}),s=t=>a({url:"/api/updateApi",method:"post",data:t}),d=t=>a({url:"/api/getAllApis",method:"post",data:t}),i=t=>a({url:"/api/deleteApi",method:"post",data:t}),o=t=>a({url:"/api/deleteApisByIds",method:"delete",data:t}),l=()=>a({url:"/api/freshCasbin",method:"get"});export{p as a,i as b,e as c,o as d,d as e,l as f,t as g,s as u};
