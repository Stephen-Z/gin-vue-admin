/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as t}from"./index-bcb8e3b8.js";const o=o=>t({url:"/authorityBtn/getAuthorityBtn",method:"post",data:o}),a=o=>t({url:"/authorityBtn/setAuthorityBtn",method:"post",data:o}),r=o=>t({url:"/authorityBtn/canRemoveAuthorityBtn",method:"post",params:o});export{r as c,o as g,a as s};
