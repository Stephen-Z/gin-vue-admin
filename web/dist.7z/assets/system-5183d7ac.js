/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s}from"./index-bcb8e3b8.js";const t=()=>s({url:"/system/getSystemConfig",method:"post"}),o=t=>s({url:"/system/setSystemConfig",method:"post",data:t}),e=()=>s({url:"/system/getServerInfo",method:"post",donNotShowLoading:!0});export{t as a,e as g,o as s};
