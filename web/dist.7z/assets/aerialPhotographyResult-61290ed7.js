/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as t}from"./index-bcb8e3b8.js";const e=()=>t({url:"/nestinfo/findNestInfoByNestIds",method:"post",data:{nestIds:[]}}),a=e=>t({url:"/ALPhotographyResult/createAerialPhotographyResult",method:"post",data:e}),o=e=>t({url:"/ALPhotographyResult/deleteAerialPhotographyResult",method:"delete",data:e}),s=e=>t({url:"/ALPhotographyResult/deleteAerialPhotographyResultByIds",method:"delete",data:e}),h=e=>t({url:"/ALPhotographyResult/updateAerialPhotographyResult",method:"put",data:e}),r=e=>t({url:"/ALPhotographyResult/findAerialPhotographyResult",method:"get",params:e}),l=e=>t({url:"/ALPhotographyResult/getAerialPhotographyResultList",method:"get",params:e});export{r as a,o as b,a as c,s as d,e as f,l as g,h as u};
