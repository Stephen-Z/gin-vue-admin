/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{s as e}from"./index-bcb8e3b8.js";const t=t=>e({url:"/nestinfo/createNestInfo",method:"post",data:t}),s=t=>e({url:"/nestinfo/deleteNestInfo",method:"delete",data:t}),o=t=>e({url:"/nestinfo/deleteNestInfoByIds",method:"delete",data:t}),a=t=>e({url:"/nestinfo/updateNestInfo",method:"put",data:t}),n=t=>e({url:"/nestinfo/findNestInfo",method:"get",params:t}),d=t=>e({url:"/nestinfo/getNestInfoInfoListWithUser",method:"get",params:t}),f=t=>e({url:"/nestinfo/getNestInfoList",method:"get",params:t});export{s as a,f as b,t as c,o as d,n as f,d as g,a as u};
