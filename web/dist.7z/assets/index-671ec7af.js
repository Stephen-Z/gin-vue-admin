/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{_ as e}from"./_plugin-vue_export-helper-1b428a4d.js";import{o as r,c as i,f as n}from"./index-bcb8e3b8.js";const s={name:"Error"},p=[n('<div class="big"><div class="inner"><img src="'+(""+new URL("notFound-4e921f05.png",import.meta.url).href)+'"><p>页面被神秘力量吸走了（如果您是开源版请联系我们修复）</p><p style="font-size:18px;line-height:40px;">常见问题为当前此角色无当前路由，如果确定要使用本路由，请到角色管理进行分配</p><p>↓</p><img src="'+(""+new URL("qm-dd0442fb.png",import.meta.url).href)+'" class="leftPic"></div></div>',1)];const t=e(s,[["render",function(e,n,s,t,o,l){return r(),i("div",null,p)}]]);export{t as default};
