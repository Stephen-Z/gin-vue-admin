/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,t){"use strict";var n;return{setters:[function(e){n=e.bD}],execute:function(){e("e",(function(){return(arguments.length>0&&void 0!==arguments[0]?arguments[0]:"").replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d")})),e("c",(function(e){return n(e)}))}}}));
