/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,t){"use strict";var r,n,c,a;return{setters:[function(e){r=e.r,n=e.o,c=e.c,a=e.b}],execute:function(){var t={style:{height:"80vh"}},i=["src"],u={name:"FormGenerator"};e("default",Object.assign(u,{setup:function(e){var u=r("https://demo.gin-vue-admin.com"),o=r("8888");return function(e,r){return n(),c("div",t,[a("iframe",{width:"100%",height:"100%",src:"".concat(u.value,":").concat(o.value,"/form-generator/#/"),frameborder:"0"},null,8,i)])}}}))}}}));
