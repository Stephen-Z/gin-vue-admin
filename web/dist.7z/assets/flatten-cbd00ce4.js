/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{m as r,a as n}from"./_Uint8Array-c14cdfe1.js";import{by as a,aP as t}from"./index-bcb8e3b8.js";var o=a?a.isConcatSpreadable:void 0;function e(n){return t(n)||r(n)||!!(o&&n&&n[o])}function i(r,a,t,o,s){var f=-1,u=r.length;for(t||(t=e),s||(s=[]);++f<u;){var l=r[f];a>0&&t(l)?a>1?i(l,a-1,t,o,s):n(s,l):o||(s[s.length]=l)}return s}function s(r){return(null==r?0:r.length)?i(r,1):[]}export{i as b,s as f};
