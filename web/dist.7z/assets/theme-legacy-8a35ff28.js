/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,t){"use strict";var r;return{setters:[function(e){r=e.s}],execute:function(){e("c",(function(e){return r({url:"/theme/createTheme",method:"post",data:e})})),e("a",(function(e){return r({url:"/theme/deleteTheme",method:"delete",data:e})})),e("d",(function(e){return r({url:"/theme/deleteThemeByIds",method:"delete",data:e})})),e("u",(function(e){return r({url:"/theme/updateTheme",method:"put",data:e})})),e("f",(function(e){return r({url:"/theme/findTheme",method:"get",params:e})})),e("g",(function(e){return r({url:"/theme/getThemeList",method:"get",params:e})}))}}}));
