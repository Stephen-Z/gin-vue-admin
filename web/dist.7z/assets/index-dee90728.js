/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
import{r as e,o as r,c as t,b as a}from"./index-bcb8e3b8.js";const o={style:{height:"80vh"}},s=["src"],n={name:"FormGenerator"},c=Object.assign(n,{setup(n){const c=e("https://demo.gin-vue-admin.com"),i=e("8888");return(e,n)=>(r(),t("div",o,[a("iframe",{width:"100%",height:"100%",src:"".concat(c.value,":").concat(i.value,"/form-generator/#/"),frameborder:"0"},null,8,s)]))}});export{c as default};
