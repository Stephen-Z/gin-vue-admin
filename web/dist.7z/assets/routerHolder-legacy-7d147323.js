/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,n){"use strict";var t,u,r,i,a,o,c,l,d,f,s;return{setters:[function(e){t=e.a8,u=e.X,r=e.o,i=e.c,a=e.d,o=e.w,c=e.a7,l=e.h,d=e.a9,f=e.C,s=e.T}],execute:function(){var n={name:"RouterHolder"};e("default",Object.assign(n,{setup:function(e){var n=t();return function(e,t){var v=u("router-view");return r(),i("div",null,[a(v,null,{default:o((function(e){var t=e.Component;return[a(c,{mode:"out-in",name:"el-fade-in-linear"},{default:o((function(){return[(r(),l(d,{include:f(n).keepAliveRouters},[(r(),l(s(t)))],1032,["include"]))]})),_:2},1024)]})),_:1})])}}}))}}}));
