/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,n){"use strict";var t,u,r,i,a,c,l,o,f,s,d;return{setters:[function(e){t=e.a8,u=e.X,r=e.o,i=e.c,a=e.d,c=e.w,l=e.a7,o=e.h,f=e.a9,s=e.C,d=e.T}],execute:function(){var n={name:"Example"};e("default",Object.assign(n,{setup:function(e){var n=t();return function(e,t){var v=u("router-view");return r(),i("div",null,[a(v,null,{default:c((function(e){var t=e.Component;return[a(l,{mode:"out-in",name:"el-fade-in-linear"},{default:c((function(){return[(r(),o(f,{include:s(n).keepAliveRouters},[(r(),o(d(t)))],1032,["include"]))]})),_:2},1024)]})),_:1})])}}}))}}}));
