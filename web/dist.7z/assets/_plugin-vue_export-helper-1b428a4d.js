/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
const o=(o,t)=>{const c=o.__vccOpts||o;for(const[s,n]of t)c[s]=n;return c};export{o as _};
