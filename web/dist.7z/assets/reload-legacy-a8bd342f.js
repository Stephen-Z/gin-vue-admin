/*! 
 Build based on gin-vue-admin 
 Time : 1697623176000 */
System.register(["./index-legacy-56ea4251.js"],(function(e,t){"use strict";var n,u,r;return{setters:[function(e){n=e.u,u=e.o,r=e.c}],execute:function(){var t={name:"Reload"};e("default",Object.assign(t,{setup:function(e){return n().go(-1),function(e,t){return u(),r("div")}}}))}}}));
